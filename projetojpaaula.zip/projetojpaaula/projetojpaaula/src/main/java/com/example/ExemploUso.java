package com.example;

import com.example.dao.UsuarioDAO;
import com.example.dao.TarefaDAO;
import com.example.dao.CategoriaTarefaDAO;
import com.example.model.Usuario;
import com.example.model.Tarefa;
import com.example.model.CategoriaTarefa;

import java.time.LocalDateTime;
import java.util.List;

public class ExemploUso {
    
    public static void main(String[] args) {
        // Declarar os DAOs fora do bloco try para poder acessá-los no finally
        UsuarioDAO usuarioDAO = null;
        TarefaDAO tarefaDAO = null;
        CategoriaTarefaDAO categoriaDAO = null;
        
        try {
            // Inicializar os DAOs
            usuarioDAO = new UsuarioDAO();
            tarefaDAO = new TarefaDAO();
            categoriaDAO = new CategoriaTarefaDAO();
            
            // Criar um usuário
            Usuario usuario = new Usuario();
            usuario.setNome("João Silva");
            usuario.setEmail("joao@email.com");
            usuario.setSenha("senha123");
            usuario = usuarioDAO.salvar(usuario);
            System.out.println("Usuário criado: " + usuario.getNome());
            
            // Criar uma categoria
            CategoriaTarefa categoria = new CategoriaTarefa();
            categoria.setNome("Trabalho");
            categoria.setDescricao("Tarefas relacionadas ao trabalho");
            categoria = categoriaDAO.salvar(categoria);
            System.out.println("Categoria criada: " + categoria.getNome());
            
            // Criar algumas tarefas
            Tarefa tarefa1 = new Tarefa();
            tarefa1.setTitulo("Implementar JPA");
            tarefa1.setDescricao("Criar projeto com JPA");
            tarefa1.setStatus(Tarefa.Status.PENDENTE);
            tarefa1.setPrioridade(Tarefa.Prioridade.ALTA);
            tarefa1.setUsuario(usuario);
            tarefa1.setCategoria(categoria);
            tarefa1.setDataVencimento(LocalDateTime.now().plusDays(7));
            tarefaDAO.salvar(tarefa1);
            
            Tarefa tarefa2 = new Tarefa();
            tarefa2.setTitulo("Estudar Spring");
            tarefa2.setDescricao("Aprender Spring Framework");
            tarefa2.setStatus(Tarefa.Status.EM_ANDAMENTO);
            tarefa2.setPrioridade(Tarefa.Prioridade.MEDIA);
            tarefa2.setUsuario(usuario);
            tarefa2.setCategoria(categoria);
            tarefa2.setDataVencimento(LocalDateTime.now().plusDays(14));
            tarefaDAO.salvar(tarefa2);
            
            // Exemplos de consultas
            System.out.println("\nTarefas pendentes:");
            List<Tarefa> tarefasPendentes = tarefaDAO.buscarPorStatus(Tarefa.Status.PENDENTE);
            tarefasPendentes.forEach(t -> System.out.println("- " + t.getTitulo()));
            
            System.out.println("\nTarefas de alta prioridade:");
            List<Tarefa> tarefasAltaPrioridade = tarefaDAO.buscarPorPrioridade(Tarefa.Prioridade.ALTA);
            tarefasAltaPrioridade.forEach(t -> System.out.println("- " + t.getTitulo()));
            
            System.out.println("\nTarefas do usuário:");
            List<Tarefa> tarefasUsuario = tarefaDAO.buscarPorUsuario(usuario.getId());
            tarefasUsuario.forEach(t -> System.out.println("- " + t.getTitulo()));
            
            // Atualizar uma tarefa
            tarefa1.setStatus(Tarefa.Status.EM_ANDAMENTO);
            tarefaDAO.atualizar(tarefa1);
            System.out.println("\nStatus da tarefa atualizado para: " + tarefa1.getStatus());
            
            // Buscar tarefas a vencer nos próximos 15 dias
            LocalDateTime inicio = LocalDateTime.now();
            LocalDateTime fim = inicio.plusDays(15);
            System.out.println("\nTarefas a vencer nos próximos 15 dias:");
            List<Tarefa> tarefasAVencer = tarefaDAO.buscarTarefasAVencer(inicio, fim);
            tarefasAVencer.forEach(t -> System.out.println("- " + t.getTitulo()));
            
        } catch (Exception e) {
            System.err.println("Erro durante a execução: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Fechar os DAOs
            if (usuarioDAO != null) usuarioDAO.fechar();
            if (tarefaDAO != null) tarefaDAO.fechar();
            if (categoriaDAO != null) categoriaDAO.fechar();
        }
    }
} 