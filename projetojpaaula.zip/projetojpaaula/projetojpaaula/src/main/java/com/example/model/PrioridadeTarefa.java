package com.example.model;

public enum PrioridadeTarefa {
    BAIXA,
    MEDIA,
    ALTA
} 