package com.example.dao;

import com.example.model.Tarefa;
import jakarta.persistence.TypedQuery;
import java.time.LocalDateTime;
import java.util.List;

public class TarefaDAO extends GenericDAO<Tarefa> {
    
    public TarefaDAO() {
        super(Tarefa.class);
    }
    
    public List<Tarefa> buscarPorStatus(Tarefa.Status status) {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.status = :status", Tarefa.class);
        query.setParameter("status", status);
        return query.getResultList();
    }
    
    public List<Tarefa> buscarPorPrioridade(Tarefa.Prioridade prioridade) {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.prioridade = :prioridade", Tarefa.class);
        query.setParameter("prioridade", prioridade);
        return query.getResultList();
    }
    
    public List<Tarefa> buscarPorUsuario(Long usuarioId) {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.usuario.id = :usuarioId", Tarefa.class);
        query.setParameter("usuarioId", usuarioId);
        return query.getResultList();
    }
    
    public List<Tarefa> buscarPorCategoria(Long categoriaId) {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.categoria.id = :categoriaId", Tarefa.class);
        query.setParameter("categoriaId", categoriaId);
        return query.getResultList();
    }
    
    public List<Tarefa> buscarTarefasVencidas() {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.dataVencimento < :agora AND t.status != :concluida", 
            Tarefa.class);
        query.setParameter("agora", LocalDateTime.now());
        query.setParameter("concluida", Tarefa.Status.CONCLUIDA);
        return query.getResultList();
    }
    
    public List<Tarefa> buscarTarefasAVencer(LocalDateTime dataInicio, LocalDateTime dataFim) {
        TypedQuery<Tarefa> query = em.createQuery(
            "SELECT t FROM Tarefa t WHERE t.dataVencimento BETWEEN :inicio AND :fim", 
            Tarefa.class);
        query.setParameter("inicio", dataInicio);
        query.setParameter("fim", dataFim);
        return query.getResultList();
    }
} 