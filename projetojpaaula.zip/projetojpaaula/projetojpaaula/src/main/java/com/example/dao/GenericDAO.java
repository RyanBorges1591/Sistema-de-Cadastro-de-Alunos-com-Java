package com.example.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;
import java.util.Optional;

public abstract class GenericDAO<T> {
    
    protected static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("todo-list-pu");
    protected EntityManager em;
    protected Class<T> entityClass;
    
    public GenericDAO(Class<T> entityClass) {
        this.entityClass = entityClass;
        this.em = emf.createEntityManager();
    }
    
    public T salvar(T entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
        return entity;
    }
    
    public T atualizar(T entity) {
        em.getTransaction().begin();
        T updated = em.merge(entity);
        em.getTransaction().commit();
        return updated;
    }
    
    public void deletar(Long id) {
        em.getTransaction().begin();
        T entity = em.find(entityClass, id);
        if (entity != null) {
            em.remove(entity);
        }
        em.getTransaction().commit();
    }
    
    public Optional<T> buscarPorId(Long id) {
        return Optional.ofNullable(em.find(entityClass, id));
    }
    
    @SuppressWarnings("unchecked")
    public List<T> listarTodos() {
        return em.createQuery("SELECT e FROM " + entityClass.getSimpleName() + " e").getResultList();
    }
    
    public void fechar() {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }
} 