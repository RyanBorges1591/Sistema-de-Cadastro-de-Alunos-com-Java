package com.example.dao;

import com.example.model.CategoriaTarefa;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class CategoriaTarefaDAO extends GenericDAO<CategoriaTarefa> {
    
    public CategoriaTarefaDAO() {
        super(CategoriaTarefa.class);
    }
    
    public List<CategoriaTarefa> buscarPorNome(String nome) {
        TypedQuery<CategoriaTarefa> query = em.createQuery(
            "SELECT c FROM CategoriaTarefa c WHERE LOWER(c.nome) LIKE LOWER(:nome)", 
            CategoriaTarefa.class);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();
    }
    
    public boolean existeNome(String nome) {
        TypedQuery<Long> query = em.createQuery(
            "SELECT COUNT(c) FROM CategoriaTarefa c WHERE LOWER(c.nome) = LOWER(:nome)", 
            Long.class);
        query.setParameter("nome", nome);
        return query.getSingleResult() > 0;
    }
} 